﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_8
{
    class Dice
    {
        //declare variables and constants
        const int ONE = 1;
        const int TWO = 2;
        const int THREE = 3;
        const int FOUR = 4;
        const int FIVE = 5;
        const int SIX = 6;
        int DiceOne;
        int DiceTwo;
        int DicePicOne;
        int DicePicTwo;
        //Method Name:roll method
        //Parameters:none
        //Returns:
        //Purpose:generates two random values between 1-6 and displays the appropriate image representation of that dice face
        public void roll()
        {
            Random dice = new Random();
            DiceOne = dice.Next(1, 7);
            DiceTwo = dice.Next(1, 7);
        }
        //Method Name:get DiceOne method
        //Parameters:
        //Returns:DiceONe
        //Purpose:getter for the Value of DiceOne
        public int getDiceOne()
        {
            return DiceOne;
        }
        //Method Name:get DiceOne method
        //Parameters:
        //Returns:DiceONe
        //Purpose:gets value of diceTwo by reference
        public void getDiceTwo(ref int value)
        {
            value = DiceTwo;
        }
    }
}
