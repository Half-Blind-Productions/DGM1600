﻿// Author: Wesley Messer    
// Assignment: Lab 23
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/5/2017
// Description: An Array that promps the user for it's input and then displays it.

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_23
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaring constants and variables
            const int SIZE = 10;
            int numInput = 1;
            int numValues = 0;

            //states size of array and creates it as an object
            int[] userinput = new int[SIZE];
            //loops through each value of the array and has the user assign it and store it fo rlater
            do
            {
                //tells user to put values for each index
                Console.WriteLine("Please enter a score or press 0 to quit");
                numInput = int.Parse(Console.ReadLine());
                //if user inputs anything other then zero then increment the index number of the user input array
                if (numInput != 0)
                {
                    userinput[numValues++] = numInput;
                }

            //prints the input for each index 
            } while (numInput != 0);
            Console.WriteLine();
            PrintArray(userinput, numValues);
            Console.WriteLine();
            Console.WriteLine($"{ProdArray(userinput, numValues)}");
            Console.ReadLine();
            //{
            //    //writes the sum of the indexes of the array
            //   PrintArray(userinput,numValues);
            //    Console.ReadKey();
            //}
        }

        //prints each index inputed by the user
        static void PrintArray(int[] input, int values)
        {
            for (int i = 0; i < values; i++)
            {
                Console.WriteLine(input[i]);
            }
            
        }

        //multiplies the indexes of the array user input together
        static int ProdArray(int[] number, int values)
        {
            int prod = 1;
            for (int i = 0; i < values; i++)
            {
                prod *= number[i];
            }
            return prod;
        }


    }
}


