﻿// Author: Wesley Messer
// Assignment: Lab #10
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004 
// Date Written: 2/13/2017 
// Description: Calculates and display the hypotunuse of a triangle from a user's input

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace HypCal_Lab_10_Feb_2017
{
    class Program
    {

        static void Main(string[] args)
        {
            //Ask the user to enter the length of one side of a right triangle.
            WriteLine("Please enter lenght of side a");
            //Get the user's input and saves it in an appropriate variable.
            double sideA = double.Parse(ReadLine());
            //Ask the user to enter the length of the other side of the triangle.
            WriteLine("Please enter lenght of side b");
            //Get the user's input and saves it in an appropriate variable.
            double sideB = double.Parse(ReadLine());
            //Call your CalcHypotenuse method and pass in the lengths of the two sides of the triangle as parameters.
            double Hypotunuse = CalcHypotenuse(sideA, sideB);
            //Save the value returned by the method in an appropriate variable.
            //Properly label and display the value returned by the method.
            WriteLine($"The Hypotunuse is {Hypotunuse}");
            ReadKey();
        }
        
        //Name:CalcHypotenuse Method
        //Purpose: take in two sides of a right triangle and return the hypotunuse; 
        //Inputs; The length of the width and height of a triangle
        //Output: lenght of the hypotenuse    
        //Returns: Double
        static double CalcHypotenuse(double side1, double side2)
        {
            //get Side a length
            //get side b length
            //square a
            double side1squared = side1 * side1;
            //square b
            double side2squared = side1 * side1;
            //sum square root
            double squaresum = side1squared + side2squared;
            //take square root
            double Hypotunuse = System.Math.Sqrt(squaresum);
            //return hypotunuse
            return Hypotunuse;
        }
    }

}
