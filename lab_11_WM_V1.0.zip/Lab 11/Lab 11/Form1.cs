﻿// Author: WesleyMesser
// Assignment: Lab #11
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 2/15/2017 
// Description: A gui that calculates the hypotnuse of a triangle from user input

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        // The button1_Click method
        // Purpose: to Call the CalcHypotenuse Method and pass the side 1 and side 2 values to it
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void button1_Click(object sender, EventArgs e)
        {
            //get side length a and convert;
            double sideA = Convert.ToDouble(A_Box.Text);
            //get side length a and convert;
            double sideB = Convert.ToDouble(B_Box.Text);
            //call CalcHypotenuse Method and pass values of sideA and sideB into it
            double hypotenuse = CalcHypotenuse(sideA, sideB);
            //return and convert value hypotenuse
            C_Box.Text = Convert.ToString(hypotenuse);

        }
        //Name:CalcHypotenuse Method
        //Purpose: take in two sides of a right triangle and return the hypotunuse; 
        //Inputs; The length of the width and height of a triangle
        //Output: lenght of the hypotenuse    
        //Returns: Double
        static double CalcHypotenuse(double side1, double side2)
        {
            //square side 1 value store in side1sq
            double side1sq = (side1 * side1);
            //square side 2 value store in side2sq
            double side2sq = (side2 * side2);
            //add side1 squared and side 2 squared store in hypoSq
            double hypoSq = side1sq + side2sq;
            //take square root of hyposq store in hypotenuse 
            double hypotensuseValue = Math.Sqrt(hypoSq);
            //return hypotenuse value
            return hypotensuseValue;
}
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The AboutToolStripMenuItem1 method
        // Purpose: To display information about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welsey Messer\nCS1400\nLab #11");
        }
    }
}
