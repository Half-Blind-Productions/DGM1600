﻿// Author: Wesley Messer
// Assignment: Lab6
// Instructor: Timothy Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 1/12/17 
// Description: A short gui program that has an exit and about function

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_wm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: closes window and ends the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The aboutToolStripMenuItem method
        // Purpose: To Show some info aboutme
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welsey Messer\nCS1400\nLab #6");
        }
        // The DiamBox_Leave Method
        // Purpose: Get a value from the user and calculate the rotations 
        // per mile from it.
        // Parameters: The sending object, and the event arguments
        // Returns: none
        private void DiamBox_Leave(object sender, EventArgs e)
        {
            //declaring constants PI and Inches in a mile
            
            
            //takes users input
            
            //multiply input by 3.1415
            //take answer, and put it in Circumference
            
            //divide the inchsInMile constant of 63,360 
            //by the Circumferance
            
            //Show the result in RPMiBox
            
        }
        //ignore this method
        private void ClearButton_MouseDown(object sender, MouseEventArgs e)
        {
            //superflous
            
        }
        // The ClearButton_Click Method
        // Purpose: Clears user input in all boxes on the form
        // Parameters: The sending object, and the event arguments
        // Returns: none
        private void ClearButton_Click(object sender, EventArgs e)
            //clear user input and output
        {
            
        }
    }
}
