﻿// Author: Wesley Messer
// Assignment: project 9
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/7/2017 
// Description: a Program that stores and calculates the total scores of a bowling team

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_9
{
    class Program
    {
        static void Main(string[] args)
        {
            //create bowling team object
            Bowling_Team BT = new Bowling_Team();
            //declare variables
            string ScoreList = "";
            string Input = "start";
            int Score = 0;
            string Name = "";
            const int SPLITSIZE = 2;
            string[] MySplit = new string[SPLITSIZE];
            //Main loop function
            while (Input != "")
            {
                //tell user to end by entering an empty line
                Console.WriteLine("to finish leave empty and press enter");
                //get users name//get users score
                Input = Console.ReadLine();
                //creates array for score and name
                MySplit = Input.Split(' ');
                //takes user input and splits it into name and score and stores it into an array acordingly
                if(Input !="")
                    {
                    Name = MySplit[0];
                    Score = int.Parse(MySplit[1]);
                    BT.GetInput(Name, Score);
                    }
            }
            //tell the user input is compleate 
            Console.WriteLine("input complete");
            Console.WriteLine("here are the scores of the game");
            //display the scores of the game
            BT.ScoreList();
            //display this score and the person who it belongs to
            Console.WriteLine($"HighScore is {BT.GetHigh()}");
            //display this score and the person who it belongs to
            Console.WriteLine($"LowScore is {BT.GetLow()}");
            //display average score
            Console.WriteLine($"AverageScore is {BT.CalcAverage()}");
            Console.ReadKey();          
        }
    }
}
