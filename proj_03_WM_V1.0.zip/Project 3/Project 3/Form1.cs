﻿// Author: Wesley Messer
// Assignment: project#3
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 2/10/2017 
// Description: A program that calculates times for delivery based on a .25 time increse delay

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The aboutToolStripMenuItem1 method
        // Purpose: displays basic info about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wesley Messer\nCS1400\nProject #3");
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The calcButtonClick method
        // Purpose: Calculates new arrival time from old arrival time
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void CalcButton_Click(object sender, EventArgs e)
        {
            //declare constants int MINCOVERT = 60  double DELAY = .25
            const int MINCONVERT = 60;
            const int DELAY = 4;
            const int Separate = 100;
            //declare variables int StartTime, int EndTime, int ArrivalTime int OldArrival double Delay
            int StartTime = 0;
            int EndTime = 0;
            int ArrivalTime = 0;
            int MinDiff = 0;
            int Delay = 0;
            int StartMin = 0;
            int StartHour = 0;
            int EndMin = 0;
            int EndHour = 0;
            int HourDiff = 0;
            //in the method for CalcButton take input from both boxes                                     
            StartTime = int.Parse(StartBox.Text);
            EndTime = int.Parse(EndBox.Text);
            //take times for EndTime and StartTime and separte hours from minutes for each
            EndHour = EndTime / Separate;
            EndMin = EndTime % Separate;
            StartHour = StartTime / Separate;
            StartMin = StartTime % Separate;
            //convert hours to mins and then add to minutes
            EndMin += EndHour * MINCONVERT;
            StartMin += StartHour * MINCONVERT;
            //find lenght of time fir delivery by subtracting Startmin from Endmin
            MinDiff = EndMin - StartMin;
            // calculate delay time by dividing MinDiff by DELAY and store in Delay
            Delay = MinDiff / DELAY;           
            // Add Delay to OldArrival
            MinDiff += Delay;
            StartMin += MinDiff;
            // convert back to hours and mins
            HourDiff = StartMin / MINCONVERT * Separate;
            MinDiff = StartMin % MINCONVERT;
            //combine hours and mins for milatary time
            ArrivalTime = HourDiff + MinDiff;
            //print to Arrival Box
            ArriveBox.Text = ArrivalTime.ToString();

        }


    }
}
