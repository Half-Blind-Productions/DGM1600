﻿// Author: Wesley Messer
// Assignment: project #2
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004
// Date Written: 2/2/2017 
// Description: A program that calculates the amount of gold given to members of a pirare crew

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2_captain_jack_calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The AboutToolStripMenuItem1 method
        // Purpose: tells information about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wesley Messer\nCS1400\nProject #2");
        }
        // The button1 method
        // Purpose: tells information about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void button1_Click(object sender, EventArgs e)
        {
            //Declare Constants
            const int PLAYGOLD = 3;
            const int CREWMINCAPMATE = 2;
            const double JACKSHARE = .12;
            const double MATESHARE = .08;
            //Declare Variables
            int JackShare = 0;
            int CrewShare = 0;
            int MateShare = 0;
            int FundShare = 0;
            int BootySize = 0;
            int CrewSize = 0;            
            //Take input from CrewBox
            CrewSize = int.Parse(CrewBox.Text);
            //Take input from BootyBox
            BootySize = int.Parse(BootyBox.Text);
            //Give 3 piecs of gold to each crew member
            BootySize = BootySize -((CrewSize-CREWMINCAPMATE) * PLAYGOLD);
            //give Jack 12% of remaining gold 
            JackShare = (int)(BootySize * JACKSHARE);
            BootySize = BootySize - JackShare;
            //give mate 8% of remaining gold 
            MateShare = (int)(BootySize * MATESHARE);           
            BootySize = BootySize-MateShare;
            //evenly divide remaining gold to MemberBox and back to Jack and mate
            CrewShare = BootySize / CrewSize;
            JackShare += CrewShare;
            MateShare += CrewShare;
            //put in Jack Box
            JackBox.Text = JackShare.ToString();
            //put in MateBox
            MateBox.Text = MateShare.ToString();
            //put in member box
            MemberBox.Text = CrewShare.ToString();
            //take remaining gold and put it in FundBox
            BootySize = BootySize - (CrewShare*CrewSize);
            FundShare =  BootySize;
            FundBox.Text = FundShare.ToString();
        }
    }
}
