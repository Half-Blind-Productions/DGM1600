﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_9
{
    class Bowling_Team
    {
        //declare constants and variables
        int IndexOfLowscore = 0;
        int IndexOfHighscore = 0;
        int HighScore = 0;
        int LowScore = 0;
        double AverageScore = 0;
        const int SIZE = 10;
        int TeamSize = 0;
        //create bowling team score array
        private int[] Scores = new int[SIZE];
        //create bowling team name array
        private string[] Names = new string[SIZE];
        /// method name: GetHigh
        /// Parameters: none
        /// Returns: string ($"{Scores[IndexOfHighscore]} scored by {Names[IndexOfHighscore]}")
        //Purpose:calculate the highest score 
        public string GetHigh()
        {
            int High = 0;
            for (int i = 0; i < TeamSize; i++)
            {
                if (High < Scores[i])
                {
                    High = Scores[i];
                    IndexOfHighscore = i;
                }
            }
            HighScore = High;
            return ($"{Scores[IndexOfHighscore]} scored by {Names[IndexOfHighscore]}");
        }
        /// method name: ScoreList
        /// Parameters: none
        /// Returns: none
        ///Purpose:function for displaying scores
        public void ScoreList()
        {
            for (int i = 0; i < TeamSize; i++)
            {
                Console.WriteLine($"{Scores[i]} scored by {Names[i]}");
            }
        }
        /// method name: SortScore
        /// Parameters:none
        /// Returns: none
        ///Purpose:sorts arrays from highest to lowest
        public void SortScore()
        {
            for (int j = 0; j < TeamSize; j++)
            {
                for (int i = 0; i < TeamSize; i++)
                {
                    if (Scores[i] < Scores[i + 1])
                    {
                    SwapScore(ref Scores[i], ref Scores[i + 1]);
                    SwapName(ref Names[i], ref Names[i + 1]);
                    }
                }
            }
        }
        /// method name: SwapScore
        /// Parameters:the two scores to be swaped
        /// Returns: none
        ///Purpose:swaps score array contents to be sorted
        public void SwapScore(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        /// method name: SwapName
        /// Parameters: the two names to be swaped
        /// Returns: none
        ///Purpose:swaps name array contents to be sorted 
        public void SwapName(ref string a, ref string b)
        {
            string temp = a;
            a = b;
            b = temp;
        }
        /// method name: GetLow
        /// Parameters: none
        /// Returns: string ($"{Scores[IndexOfLowscore]} scored by{Names[IndexOfLowscore]}")
        ///Purpose:calculate the lowest score 
        public string GetLow()
        {
            int Low = 300;
            for (int i = 0; i < TeamSize; i++)
            {
                if (Low > Scores[i])
                {
                    Low = Scores[i];
                    IndexOfLowscore = i;
                }
            }
            LowScore = Low;
            return ($"{Scores[IndexOfLowscore]} scored by {Names[IndexOfLowscore]}");
        }
        /// method name:CalcAverage
        /// Parameters: none
        /// Returns: Double
        /// Purpose:calculate the average score 
        public double CalcAverage()
        {
            double sum = 0;
            for (int i = 0; i < TeamSize; i++)
            {
                sum += Scores[i];
            }
            AverageScore = sum / TeamSize;
            return AverageScore;
        }
        /// method name: GetLow
        /// Parameters: string, int
        /// Returns: none
        ///Purpose://get input from main program 
        public void GetInput(string name, int score)
        {
            Names[TeamSize] = name;
            Scores[TeamSize] = score;
            TeamSize++;
        }
    }
}
