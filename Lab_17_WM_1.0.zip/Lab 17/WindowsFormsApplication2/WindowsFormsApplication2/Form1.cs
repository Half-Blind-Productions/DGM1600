﻿// Author: Welsey Messer
// Assignment: Lab 17
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004 
// Date Written: 3/9/2017 
// Description: A Program that tells the user what kind of shipping method they have selected

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To show info about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wesley Messer\n Lab 17\n Timothy D stanley\n 3/9/2017");
        }
        // The ComboBox method
        // Purpose: To get and display the selected kind of shipping from the user
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = comboBox1.Text;
            MessageBox.Show("You selected " + selectedItem);
        }
        // The ExpressRadio method
        // Purpose: to display the express shipping method to the user if selected
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void ExpressRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (ExpressRadio.Checked)
                MessageBox.Show("selected Express Shipping");
        }
        // The SamedayRadio method
        // Purpose: To display same day shipping to the user if selected
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void SamedayRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (SamedayRadio.Checked)
                MessageBox.Show("selected Same Day shipping");
        }
        // The StandardRadio method
        // Purpose: To display standard shipping to the use if selected
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void StandardRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (StandardRadio.Checked)
                MessageBox.Show("selected Standard Shipping");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
//1.comboBox1.Text
//2.comboBox1.SelectedIndex