﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StandardRadio = new System.Windows.Forms.RadioButton();
            this.ExpressRadio = new System.Windows.Forms.RadioButton();
            this.SamedayRadio = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Standard Shipping",
            "Express Shipping",
            "Same Day Shippping"});
            this.comboBox1.Location = new System.Drawing.Point(12, 53);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "Click to select";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // StandardRadio
            // 
            this.StandardRadio.AutoSize = true;
            this.StandardRadio.Location = new System.Drawing.Point(148, 114);
            this.StandardRadio.Name = "StandardRadio";
            this.StandardRadio.Size = new System.Drawing.Size(112, 17);
            this.StandardRadio.TabIndex = 2;
            this.StandardRadio.TabStop = true;
            this.StandardRadio.Text = "Standard Shipping";
            this.StandardRadio.UseVisualStyleBackColor = true;
            this.StandardRadio.CheckedChanged += new System.EventHandler(this.StandardRadio_CheckedChanged);
            // 
            // ExpressRadio
            // 
            this.ExpressRadio.AutoSize = true;
            this.ExpressRadio.Location = new System.Drawing.Point(148, 133);
            this.ExpressRadio.Name = "ExpressRadio";
            this.ExpressRadio.Size = new System.Drawing.Size(106, 17);
            this.ExpressRadio.TabIndex = 3;
            this.ExpressRadio.TabStop = true;
            this.ExpressRadio.Text = "Express Shipping";
            this.ExpressRadio.UseVisualStyleBackColor = true;
            this.ExpressRadio.CheckedChanged += new System.EventHandler(this.ExpressRadio_CheckedChanged);
            // 
            // SamedayRadio
            // 
            this.SamedayRadio.AutoSize = true;
            this.SamedayRadio.Location = new System.Drawing.Point(148, 156);
            this.SamedayRadio.Name = "SamedayRadio";
            this.SamedayRadio.Size = new System.Drawing.Size(118, 17);
            this.SamedayRadio.TabIndex = 4;
            this.SamedayRadio.TabStop = true;
            this.SamedayRadio.Text = "Same Day Shipping";
            this.SamedayRadio.UseVisualStyleBackColor = true;
            this.SamedayRadio.CheckedChanged += new System.EventHandler(this.SamedayRadio_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Shipping method";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Shipping method";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SamedayRadio);
            this.Controls.Add(this.ExpressRadio);
            this.Controls.Add(this.StandardRadio);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.RadioButton StandardRadio;
        private System.Windows.Forms.RadioButton ExpressRadio;
        private System.Windows.Forms.RadioButton SamedayRadio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

