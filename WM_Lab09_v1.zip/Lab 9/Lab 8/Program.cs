﻿//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.

// File Prologue
// CS 1400-004
// Wesley Messer
// Lab #9
// 2/8/2017
// instructor: Timothy D Stanley
// I did not copy any code except that provided by the instructor
//---------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare constants PI and number of decimal points to round (DecResult)
            const double PI = Math.PI;            
            const int DecResult = 2;
            //declare variables radius, and SquArea, and CirArea and unwatered
            int Radius = 0;
            int SquArea = 0;
            double CirArea = 0;
            double UnWatered = 0;

            //get radius of circle from user
            Console.WriteLine("what is your circle radius?");
            Radius = int.Parse(Console.ReadLine());
            // get area of square from user
            Console.WriteLine("what is your fields area?");
            SquArea = int.Parse(Console.ReadLine());
            //take radius and multiply it by it’self (radius*radius) Then by constant PI
            //take result and set CirArea equal to it
            CirArea = (Radius * Radius) * PI;
            //subtract CirArea from SquArea set Result equal to This number
            UnWatered = SquArea - CirArea;
            //Trunkate Result down to two decimal places
            UnWatered = Math.Round(UnWatered,DecResult);
            //parse result to string and display.            
            Console.WriteLine(UnWatered.ToString());
            //wait for user to press button then close
            Console.ReadKey(true);
        }
    }
}
