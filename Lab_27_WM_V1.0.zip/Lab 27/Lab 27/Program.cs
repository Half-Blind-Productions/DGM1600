﻿// Author: Wesley Messer
// Assignment: Lab 27
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/24/2017
// Description: a program that takes data from a file and stores it in objects which are referenced in an array

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lab_27
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare Variables, including an array of Boxes
            const int MAX = 10;

            int count = 0;
            string inputLine = "";

            Box[] boxes = new Box[MAX];
            //Set counter to Zero

            //Open selected File

            // This line of code gets the path to the My Documents Folder
            string environment = System.Environment.GetFolderPath
     (System.Environment.SpecialFolder.Personal) + "\\";

            Console.WriteLine("Enter a file name in My Documents: ");
            string input = Console.ReadLine();

            // concatenate the path to the file name
            string path = environment + input;

            // now we can use the full path to get the document
            StreamReader myFile = new StreamReader(path);



            //Console.ReadLine();
            //Loop until all data is read or the array is full
            do
            {
                //-Read in all of the Data for one object, saving the data in some local variables

                inputLine = myFile.ReadLine();
                if (inputLine != null && count < MAX);
                {
                    string[] data = inputLine.Split();

                    int dataH = int.Parse(data[0]);
                    int dataW = int.Parse(data[1]);
                    int dataD = int.Parse(data[2]);

                    //-Create an object, passing the data to the constructor
                    boxes[count++] = new Box(dataH, dataW, dataD);
                    //-Save the reference to the object in the array
                    //-Increment the counter

                }
            } while (!myFile.EndOfStream);

            //Display the volume of each box object
            for (int j = 0; j< count; j++)
            {
                Console.WriteLine("The volume of the box {0:d} is {1:d} cubic inches",count + 1, boxes[j].GetVolume());
            }
            Console.ReadKey();
        }
    }
}
