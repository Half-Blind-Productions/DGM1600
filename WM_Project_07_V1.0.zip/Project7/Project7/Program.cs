﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project7
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            int Month = 0;
            int Adults = 1; //F(n-1)
            int Babies =0; //F(n-2)
            int total = 0; //F(n)
            int cages =1;
            const int CAGETOTAL = 500;

            //print colum headers
            Console.WriteLine(" Name: Wesley Messer\n Class: CS 1400\n Instructor: Timothy D Stanley\n Section: 004\n Assignment: Project 7");
            Console.WriteLine("month\tAdults\tBabies\ttotal");
            while (cages < CAGETOTAL)
            {
                //fibonacci sequence in code "{\displaystyle F_{n}=F_{n-1}+F_{n-2},}" i.e. (0.0.1.1.3.5.8.21.34.55.89.144..etc)
                Month++;
                //F_n=F_n-1 + F_n-2
                total = Adults + Babies;
                Console.WriteLine($"{Month}\t{Adults}\t{Babies}\t{total}");
                Babies = Adults;
                Adults = total;
                cages = total;
                
             
                
            }
            //print when you run out of cages
            Console.WriteLine($"you will need to buy more cadges in {Month} months");
            Console.ReadKey();


           
        }
    }
}
