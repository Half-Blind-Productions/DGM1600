﻿// Author: Wesley Messer
// Assignment: Project 12
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/24/2017
// Description: a program that Figures out pay for employees based on user input 

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Project_FlufleShuffle
{
    public partial class Form1 : Form
    {
        const int MAX = 10;
        static Employee[] EmpData = new Employee[MAX];
        static int Count = 0;
        static int Current = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// ExitToolStripMenuItem Method
        /// Parameters:none
        /// Returns:none
        /// Purpose:to close the program
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// AboutToolStripMenuItem Method
        /// Parameters:none
        /// Returns:none
        /// Purpose:to show informatioin about the program
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name:Wesley Messer\n Instructor: Timothy D Stanley\n Class:CS 1400\n Section:004\n Project:12");
        }
        /// <summary>
        /// OpenToolStripMenuItem Method
        /// Parameters:(tempnumber, tempname, tempadress, tempwage, temphours)
        /// Returns:none
        /// Purpose:Open and reads file and puts data into appropreate storage
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "text files (*.txt)|*txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = openFileDialog1.OpenFile()) != null)
                {
                    StreamReader data = new StreamReader(myStream);
                    string input = data.ReadLine();
                    //seeing if end of document and reading each line and setting it to temparary variables.                   
                    while (!data.EndOfStream)
                    {
                        int tempnumber;
                        tempnumber = int.Parse(input);
                        string tempname;
                        input = data.ReadLine();
                        tempname = input;
                        string tempadress;
                        input = data.ReadLine();
                        tempadress = input;
                        double tempwage;
                        input = data.ReadLine();
                        int temphours;
                        string[] Atemp = input.Split();
                        tempwage = double.Parse(Atemp[0]);
                        temphours = int.Parse(Atemp[1]);

                        EmpData[Count++] = new Employee(tempnumber, tempname, tempadress, tempwage, temphours); 

                        input = data.ReadLine();
                    }

                    //Name: NextButt_Click method
                    //purpose: to advance to the next person in the payroll 
                    //parameteres: none
                    //returns:none
                    NextButt_Click(sender, e);

                    
                }
            }
        }
        //Name: NextButt_Click method
        //purpose: to advance to the next person in the payroll 
        //parameteres: none
        //returns:none
        private void NextButt_Click(object sender, EventArgs e)
        {
            if (Current < Count)
            {
                NameBox.Text = EmpData[Current].GetName();
                AdressBox.Text = EmpData[Current].GetAdress();
                NetBox.Text = $"{EmpData[Current].CalcSalary():C}";
                Current++;
            }
        }
    }
}

