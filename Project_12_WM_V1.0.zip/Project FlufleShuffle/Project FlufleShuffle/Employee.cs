﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_FlufleShuffle
{
    class Employee
    {
        //All Employees have the following attributes:
        //Variables and Constants
        //employeeNumber
        int EmpNum = 0;
        //name
        string EmpName = "";
        //street address
        string EmpAdress = "";
        //hourly wage
        double EmpWage = 0.0;
        //Hours worked this week
        int EmpHrsWeek = 0;
        //employee net pay
        double EmpNetPay = 0.0;
        //employee gross pay
        double EmpGrossPay = 0.0;
        //overtime hours
        const int OvertimeHours = 40;
        //overtime pay rate
        const double OvertimePayRate = 1.5;
        //Fedral Tax
        const double FedralTax = .2;
        //State Tax
        const double StateTax = .075;
        public Employee(int number, string name, string adress, double wage, int hours)
        {
            EmpName = name;
            EmpNum = number;
            EmpAdress = adress;
            EmpWage = wage;
            EmpHrsWeek = hours;
        }
        //Every employee on the payroll will need to be represented in the program by 
        //its own Employee object. 
        //The most convenient way to handle this will be to create an array of Employee objects.

            //A constructor for the Employee class that takes arguments to initialize all of the above mentioned attributes.

            //Getters and Setters for each attribute.
        public int GetNumber()
        {
            return EmpNum;
        }
        public string GetName()
        {
            return EmpName;
        }
        public string GetAdress()
        {
            return EmpAdress;
        }
        public double GetWage()
        {
            return EmpWage;
        }
        public int GetHours()
        {
            return EmpHrsWeek;
        }
        public void SetName(string Name)
        {
            EmpName = Name;
        }
        public void SetNumber(int Number)
        {
            EmpNum = Number;
        }
        public void SetAdress(string Adress)
        {
            EmpAdress = Adress;
        }
        public void SetWage(double Wage)
        {
            EmpWage = Wage;
        }
        public void SetHours(int Hours)
        {
            EmpHrsWeek = Hours;
        }
        //Name:CalcSalary Method
        /// Parameters:(int number, string name, string adress, double wage, int hours)
        /// Returns:EmpNetPay
        /// Purpose:to calculate an employees' salary
        public double CalcSalary()
        {
            //A method, CalcSalary( ), that calculates and returns an employee's net pay as a double. 
            //An employee's gross pay is calculated
            //by multiplying the hours worked by their hourly wage.
            //Be sure to give time-and-a-half for overtime (anything over 40 hours). 
            if (EmpHrsWeek > OvertimeHours)
            {
                EmpGrossPay = EmpHrsWeek * (EmpWage * OvertimePayRate);
            }
            else
            {
                EmpGrossPay = EmpHrsWeek * EmpWage;
            }
            //To compute the net pay, deduct 20% for Federal income tax, and 7.5% for state income tax.
            EmpNetPay = EmpGrossPay - ((EmpGrossPay*FedralTax) + (EmpGrossPay*StateTax));
            return EmpNetPay;
        }
       
    }
}
