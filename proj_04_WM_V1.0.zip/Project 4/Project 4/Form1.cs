﻿// Author: Welsey Messer
// Assignment: Project #4
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 2/16/2017 
// Description: Calculates the side lenght for C and the angle of a and b in a triangle

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_4
{
    public partial class Form1 : Form
    {
        //declaring constants
        const double RAD_TO_DEGREES = 180 / Math.PI;
        const double DEGRESS_TO_RAD = Math.PI / 180;
        const double TWICEVAL = 2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //Name:CalcSide_C Method
        //Purpose: take in two sides of triangle and angle c; 
        //Inputs; The length of the width and height of a triangle and angle c
        //Output: lenght of the hypotenuse    
        //Returns: Double
        static double CalcSide_c(double side1, double side2, double angleCdegrees)
        {
            //convert angle C's degrees into Radians
            double angleCRads = angleCdegrees * DEGRESS_TO_RAD;
            //square side 1/a
            double side1sq = (side1 * side1);
            //square side 2/b
            double side2sq = (side2 * side2);
            //finds side c squared
            double sidecsq = side1sq + side2sq - TWICEVAL * side1 * side2 * Math.Cos(angleCRads);
            //finds square root of side c length
            double sidecValue = Math.Sqrt(sidecsq);
            //puts side c into side c value
            return sidecValue;

        }

        // The CalcButton_Click method
        // Purpose: To Call method CalcSide_C CalcAngle_A and CalcAngle_B Pass input from side A side B and angle C
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void CalcButton_Click(object sender, EventArgs e)
        {
            //takes input from LenghtABox and converts it to a double stores it in sideA
            double sideA = Convert.ToDouble(LengthABox.Text);
            //takes input from LenghtBBox and converts it to a double stores it in sideB
            double sideB = Convert.ToDouble(LengthBBox.Text);
            //takes input from AngleCBox and converts it to a double stores it in AngleC
            double angleC = Convert.ToDouble(AngleCBox.Text);
            //Calls method CalcSide_C and passes Values of sideA sideB and angleC into it
            double sideC = CalcSide_c(sideA, sideB, angleC);
            //Calls method CalcAngle_b and passes Values of sideA sideB side C and angleC into it
            double angleB = CalcAngle_b(sideA, sideB, sideC, angleC);
            //Calls method CalcAngle_a and passes Values of sideA sideB side C and angleC into it
            double angleA = CalcAngle_a( angleB, angleC);
            //Prints value of sideC into LengthCBox
            LengthCBox.Text = Convert.ToString(sideC);
            //Prints value of angleA into AngleBoxA
            AngleABox.Text = Convert.ToString(angleA);
            //Prints value of angleB into AngleBoxB
            AngleBBox.Text = Convert.ToString(angleB);
        }
        //Name:CalcAngle_A Method
        //Purpose: take in two sides of triangle and angle c to calculate angle a; 
        //Inputs; The length of the width and height and hypotenuse of a triangle and angle c  
        //Output: Angle of a in degrees    
        //Returns: Double
        static double CalcAngle_a( double Angleb, double angleC)
        {
            //take sum of angle b and c and subtract from 180 store in Anglea
            double Anglea = 180 - (Angleb + angleC);
            //return Anglea
            return Anglea;

        }
        //Name:CalcAngle_B Method
        //Purpose: take in two sides of triangle and angle c to calculate angle b; 
        //Inputs; The length of the width and height and hypotenuse of a triangle and angle c  
        //Output: Angle of b in degrees    
        //Returns: Double
        static double CalcAngle_b(double side1, double side2, double side3, double anglecdegrees)
        {
            //convert angle c to radians
            double anglecRads = anglecdegrees * DEGRESS_TO_RAD;
            //calculate angle b in radians
            double Angleb = Math.Asin(side2 * (Math.Sin(anglecRads)/ side3));
            //convert angle b to degrees
            Angleb = Angleb * RAD_TO_DEGREES;
            //creturn Angleb
            return Angleb;

        }
        // The Button2_Click method
        // Purpose: To Clear all text fields
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void button2_Click(object sender, EventArgs e)
        {
            //clear all boxes of user input and otherwise
            AngleABox.Clear();
            AngleBBox.Clear();
            AngleCBox.Clear();
            LengthABox.Clear();
            LengthBBox.Clear();
            LengthCBox.Clear();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //closes program
            this.Close();
        }
        // The AboutToolStripMenuItem1 method
        // Purpose: To show information about the Program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //displays window that shows information about program
            MessageBox.Show("Welsey Messer\n CS1400\n Project #4");
        }
    }

    }


    

