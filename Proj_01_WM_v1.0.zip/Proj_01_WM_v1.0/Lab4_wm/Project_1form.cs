﻿// Author: Wesley Messer
// Assignment: Project 1
// Instructor: Timothy Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 1/23/17 
// Description: A short gui program that has an exit and about function

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_wm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: closes window and ends the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The aboutToolStripMenuItem method
        // Purpose: To Show some info aboutme
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wesley\nCS1400\nProject 1");
        }

        // The MealAmount_leave method
        // Purpose: To Show some info aboutme
        // Parameters: Takes users input and calculates
        //the apropriate tips respectivly for poor average and excelent service
        // Returns: None
        private void MealAmount_Leave(object sender, EventArgs e)
        {
            const double POOR = 0.1;
            const double AVERAGE = 0.15;
            const double EXCELENT = 0.2;
            double mealAmt = double.Parse(AmountBox.Text);
            double poorTip = mealAmt * POOR;
            double averageTip = mealAmt * AVERAGE;
            double excelentTip = mealAmt * EXCELENT;
            string poorText = $"{poorTip:c}";
            string averageText = $"{averageTip:c}";
            string excelentText = $"{excelentTip:c}";
            PoorBox.Text = poorText;
            AverageBox.Text = averageText;
            ExcelentBox.Text = excelentText;
        }
    }
}
