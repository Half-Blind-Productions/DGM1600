﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_13
{
    class Token_Machine
    {
        //Declaring class Variables and constants
        const int TOKEN = 100;
        private int numTokens = TOKEN;
        private int numQuarters = 0;
        
        // The Reset method
        // Purpose: to reset the values of numTokens and numQuarters
        // Parameters: none
        // Returns: None
        public void Reset()
        {
         // setting value for numTokens
         numTokens = TOKEN;
         // setting value for numQuarters   
         numQuarters = 0;
    }
        // The CountToken method
        // Purpose: to reset the text boxes to default values
        // Parameters: none
        // Returns: the int numTokens
        public int CountTokens()
        {
            //returns the value of numTokens
            return numTokens;
        }
        // The CountQuarters method
        // Purpose: to return the value of numQuarters to it's inital value
        // Parameters: none
        // Returns: the int numQuarters
        public int CountQuarters()
        {
            //returns the value of numTokens
            return numQuarters;
        }
        // The GetToken method
        // Purpose: to add a quarter for every token taken away
        // Parameters: none
        // Returns: None
        public void GetToken()
        {
            //subtracts 1 from the value of numtokens each time the method is executed
            numTokens--;
            //Adds 1 from the value of numquarters each time the method is executed
            numQuarters++;
        }
    }
}
