﻿// Author: Wesley Messer
// Assignment: Lab #13
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004 
// Date Written: 2/23/2017 
// Description: A Program that uses an object that simulates an arcade token machine

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_13
{
    public partial class Form1 : Form
    {
        // a class level reference to a token machine
        private Token_Machine tm;
        public Form1()
        {
            InitializeComponent();
            // create a token machine object
            tm = new Token_Machine();
            tm.Reset();
            QuarterBox.Text = tm.CountQuarters().ToString();
            TokenBox.Text = tm.CountTokens().ToString();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Closes program
            this.Close();
        }
        // The AboutToolStripMenuItem1 method
        // Purpose: To display info about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //shows information about the program in a new window
            MessageBox.Show("Wesley Messer\nCS1400\nLab #13");
        }
        // The button2 method
        // Purpose: to reset the text boxes to default values
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void button2_Click(object sender, EventArgs e)
        {
            //acessing reset method from token machine object
            tm.Reset();
            //Reset value from CountQuarters method being accessed from token machine object
            QuarterBox.Text =  tm.CountQuarters().ToString();
            //Reset value from Counttoken method being accessed from token machine object
            TokenBox.Text = tm.CountTokens().ToString();
            
        }
        // The button1 method
        // Purpose: to reset the text boxes to default values
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void button1_Click(object sender, EventArgs e)
        {
            //accessing method get token from token machine object
            tm.GetToken();
            //display value from CountQuarters method being accessed from token machine object
            QuarterBox.Text = tm.CountQuarters().ToString();
            //display value from Counttoken method being accessed from token machine object
            TokenBox.Text = tm.CountTokens().ToString();
        }
    }
}
