﻿// Author: Wesley Messer
// Assignment: Lab 19
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 3/15/2017 
// Description: a dice roller that gives a user two random numbers that are in the range of 1-6 (just sudocode at this point)

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_18
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare varibles and constants
            int RandoOne;
            int RandoTwo;
            string response;
            const int BOX = 6;
            //Create a Random Number generator object.
            Random RandomNum = new Random();
            do
            {
                //Ask the user if they want to roll the dice
                Console.WriteLine("do you want to roll the dice? Y/N");
                //Get the user's response and validate that it is either 'y' or 'n'. If it is not a 'y' or an 'n', 
                response = Console.ReadLine();
                while (response != "y" && response != "n")
                {
                    //otherwise tell the user that the input is invalid and ask for another response.
                    Console.WriteLine("that input is invalid please give either y or n");
                    response = Console.ReadLine();
                }
                //}
                //while (response != "y" && response != "n");
                //If the user responds with a 'y' then Generate two random numbers in the range 1 - 6
                if (response == "y")
                {
                    RandoOne = RandomNum.Next(1, BOX + 1);
                    RandoTwo = RandomNum.Next(1, BOX + 1);

                    if (RandoOne == BOX && RandoTwo == BOX)
                    {
                        //If the two numbers are 6 and 6, display the message "You rolled boxcars"
                        Console.WriteLine("You rolled boxcars");
                    }
                    else if (RandoOne == 1 && RandoTwo == 1)
                    {
                        //If the two numbers are 1 and 1 display the messag;e "You rolled snake-eyes"
                        Console.WriteLine("you rolled snake-eyes");
                    }
                    else
                    {
                        //In all other cases display the message "You rolled ..." and show the values of the two random numbers
                        Console.WriteLine($"you rolled, {RandoOne} and {RandoTwo}");
                    }
                }
            }
            //Return to step 2 and ask the user again if they want to roll the dice.
            while (response == "y");       
            //If the user responds with a 'n', print a goodbye message and quit.         
            Console.WriteLine("goodbye");
            Console.ReadKey(true);

            //1.int d1 = joe.Next(5, 10+1)
            //2.do while Loop
        }
    }
}
