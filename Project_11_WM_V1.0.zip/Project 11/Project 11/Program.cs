﻿// Author: Wesley Messer    
// Assignment: Project 11
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/19/2017
// Description: to tell you what the dissapation voltage of a set of risitors is and if it passed based off a max power rating

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Project_11
{
    class Program
    {
        static void Main()
        {
            //create resistor object
            Resistor Res = new Resistor();
            //info for the user
            Console.WriteLine("Resistor Batch Test Analsis Program");
            Console.WriteLine("Data File must be in your Documents Folder");
            // This line of code gets the path to the My Documents Folder
            string environment = System.Environment.GetFolderPath
            (System.Environment.SpecialFolder.Personal) + "\\";

            Console.WriteLine("Enter a file name in My Documents: ");
            string input = Console.ReadLine();

            // concatenate the path to the file name
            string path = environment + input;

            // now we can use the full path to get the document
            StreamReader myFile = new StreamReader(path);
            //read line of program and split it
            const int SPLITSIZE = 2;
            string[] MySplit = new string[SPLITSIZE];
            string temp = myFile.ReadLine();
            MySplit = temp.Split();
            //set dissapation and parse
            Res.SetPower(int.Parse(MySplit[1]));
            //set Resistance and parse
            Res.SetResistance(int.Parse(MySplit[0]));
            string inputString;
            //set voltages for each entry in document
            do
            {
                //if there is information read in from the document set the voltage
                inputString = myFile.ReadLine();
                if (inputString != null)
                {                    
                    //set voltage
                    Res.SetVoltage(int.Parse(inputString));
                }
            } while (inputString != null);
            //print out dissapation values
            Res.Print();
            Console.ReadLine();
        }//End Main()
    }
}