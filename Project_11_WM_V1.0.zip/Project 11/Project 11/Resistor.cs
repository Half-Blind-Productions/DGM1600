﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_11
{
    class Resistor
    {
        //declare variables and constans
        const int MAX_RESISTORS = 50;
        private double resistence = 0;
        public int MaxPower = 0;
        //array of doubles for power
        double [] DissapationVoltages;        
        int Size = 0;
        //array of doubles for voltages
        int[] voltages;
        public Resistor()
        {
            voltages = new int[MAX_RESISTORS]; 
        }
        //calculate pass fail
        /// Name:PassFail method
        /// parameters: int D dissapation volatges
        /// returns: boolean based on greater or less then power values vs max power values
        /// Purpose:sees if greater or less then power values vs max power values and says true or false acordingly
        public bool PassFail(int D)
        {
            if (CalcDissapation(D) < MaxPower)
            {
                return false;
            }
            else
            {
                return true;
            }
            
        }
        /// name:SetPower method
        /// parameters: int D
        /// purpose: sets power value to D
        ///returns:none
        public void SetPower(int D)
        {
            MaxPower = D;
        }
        /// Name:sets Resistance
        /// returns: none
        /// Purpose: sets power to R
        /// parameters:R
        public void SetResistance(int R)
        {
            resistence = R;
        }
        /// Name:SetVoltage
        /// Returns Sets voltage to V
        /// Returns:none
        /// parameters: V
        public void SetVoltage(int v)
        {
            voltages[Size++] = v;
        }
        public double CalcDissapation(int D)
        {
            return voltages[D] * voltages[D] / resistence;
        }
        //Name:Print
        //Parameters:none
        //returns:none
        //summery:prints out disapation and if the resistor passed based on max power value or not.
        public void Print()
        {
            Console.WriteLine("Res#\tDissapation\tPassed");
            for (int i =0; i<Size;i++)
            {
                Console.WriteLine($"{i+1}\t {CalcDissapation(i)}\t\t {PassFail(i)}");
            }
        }
    }
}
