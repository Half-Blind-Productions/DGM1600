﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_15
{
    class Triangle
    {
        //declaration of variables and constants
        private double SideA;
        private double SideB;
        const double HALF = 2;
        // The GetSideA method
        // Purpose: to return the value of SideA
        // Parameters: none
        // Returns: Double SideA
        public double GetSideA()
        {
            return SideA;
        }
        // The GetSideB method
        // Purpose: to return the value of SideB
        // Parameters: none
        // Returns: Double SideB
        public double GetSideB()
        {
            return SideB;
        }
        // The CalcSideC method
        // Purpose: to calculate the value of side C and return it
        // Parameters: none
        // Returns: Double SideC
        public double CalcSideC()
        {
            //calculates hypotenuse (A^2+B^2=c^2)
            double sideC = (SideA * SideA) + (SideB * SideB);
            //calculates hypotenuse (square root of C^2) 
            sideC = Math.Sqrt(sideC);
            return sideC;
        }
        // The CalcArea method
        // Purpose: to calculate the area of the triangle being calculated
        // Parameters: none
        // Returns: Double CalcArea
        public double CalcArea()
        {
            //calculates area (A*B/2= area)
            double CalcArea = (SideA * SideB) / HALF;
            return CalcArea;
        }
        // The SetsideA method
        // Purpose: to set the value of SideA
        // Parameters: double sidea
        // Returns: none
        public void SetsideA(double sidea)
        {
            SideA = sidea;
        }
        // The SetsideB method
        // Purpose: to set the value of SideA
        // Parameters: double sideb
        // Returns: none
        public void SetSideB(double sideb)
        {
            SideB = sideb;
        }
    }
   
}

