﻿// Author: wesley messer
// Assignment: Lab #15
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: the Date 
// Description: A gui that calculates a right triangle using a built in class

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_15
{
    public partial class Form1 : Form
    {
        private Triangle Tri;
        public Form1()
        {
            Tri = new Triangle();
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The AboutToolStripMenuItem1 method
        // Purpose: To display info about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wesley Messer\nCS1400\nLab #15");
        }
        // The button method
        // Purpose: to call the methods for calchypotenuse and calcArea from the triangle class
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void button1_Click(object sender, EventArgs e)
        {
            //get and convert user input for side A and side B from user
            Tri.SetsideA(double.Parse (SideABox.Text));
            Tri.SetSideB(double.Parse(SideBBox.Text));
            //call method CalcSideC from triangle object pass value to hypotenuse
            double hypotenuse = Tri.CalcSideC();
            //convert hypotenuse to a string and output it to SideCBox
            SideCBox.Text = hypotenuse.ToString();
            //call method CalcArea from triangle object pass value to area
            double Area = Tri.CalcArea();
            //convert Area to a string and output it to AreaBox
            AreaBox.Text = Area.ToString();
        }
    }
}
