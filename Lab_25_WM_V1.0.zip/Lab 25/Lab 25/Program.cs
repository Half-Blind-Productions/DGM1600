﻿// Author: Wesley Messer
// Assignment: Lab 25
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 04/18/2017
// Description: A program that read information from a a text file and then outputs it in the console

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_25
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            int theTextFile = 0;
            int i = 0;

            //display scores
            Console.WriteLine("scores");
            //creates array
            int[] Scores = new int[50];
            //create stream Reader object 
            //get file path 
            StreamReader dataFile = new StreamReader(System.Environment.GetFolderPath
            (System.Environment.SpecialFolder.Personal) + "\\grades.txt");
            //loop reads data in file untill it reaches the end of file
            //read in int, display, and store in the array
            while (!dataFile.EndOfStream)
            {
                theTextFile = int.Parse(dataFile.ReadLine());
                Console.WriteLine(theTextFile);
                Scores[i++] = theTextFile;
            }
            //output average score.
            Console.WriteLine("Average score");
            Console.WriteLine(CalcAverage(Scores, i));



            Console.ReadKey();

        }
        //calculate the average score
            /// method name:CalcAverage
            /// Parameters: none
            /// Returns: Double
            /// Purpose:calculate the average score 
        public static double CalcAverage(int[] scores,int end)
        {
            double AverageScore = 0;
            double sum = 0;
            for (int j = 0; j < end; j++)
            {
                sum += scores[j];
            }
            AverageScore = sum / end;
            return AverageScore;
        }
    }
}
       