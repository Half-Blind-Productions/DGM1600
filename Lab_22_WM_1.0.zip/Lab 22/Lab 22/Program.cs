﻿// Author: Wesley Messer    
// Assignment: Lab 22
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/4/2017
// Description: An Array that promps the user for it's input and then displays it.

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_22
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaring constants and variables
            const int SIZE = 10;
            //states size of array and creates it as an object
            int[] userinput = new int[SIZE];
            //loops through each value of the array and has the user assign it and store it fo rlater
            for (int i = 0; i < SIZE; i++)
            {
                //tells user to put values for each index
                Console.WriteLine("Please input a value");
                //gets users input
                string Input = Console.ReadLine();
                //converts user input to int
                userinput[i] = int.Parse(Input);
            }
            //writes the sum of the indexes of the array
            Console.WriteLine($"{PrintArray(userinput)}");
            Console.ReadKey();
        }
        static int PrintArray(int[] input)
        {
            //declare variables
            int sum = 0;
            //adds each index in a loop function
            foreach (int value in input)
            {
                //adds the value of each index to the total
                sum += value;
            }
            return sum;
            
        }
    }
}


