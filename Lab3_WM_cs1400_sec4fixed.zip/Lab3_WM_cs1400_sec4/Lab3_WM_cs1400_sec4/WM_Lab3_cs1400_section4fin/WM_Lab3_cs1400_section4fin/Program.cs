﻿// Author: Wesley Messer
// Assignment: Lab3
// Instructor: Timothy Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 1/12/17 
// Description:  a short program that tells the user their age in a year and how much money they have


//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_WM_cs1400_sec4
{
    class Program
    {

        static void Main()
        {
            //declaring variables
            int age;
            double money;
            string Name;

            //greets user
            Console.WriteLine("Hello my name is Hal.");
            //asks user for name
            Console.WriteLine("What is your name?");
            //stores name
            Name = (Console.ReadLine());
            //states user name and asks age
            Console.WriteLine("Hello " + Name + ", how old are you?", Name);
            //stores age
            age = int.Parse(Console.ReadLine());
            //adds one to age
            age = age + 1;
            //asks user how much money they have
            Console.WriteLine("How much money do you have " + Name + " ?", Name);
            //records money amount
            money = double.Parse(Console.ReadLine());
            //tells user how old they will be in one year and states how much money they have
            Console.WriteLine("Thanks " + Name + " You are almost " + age + " years old and you have  $" + money + "");
            //keeps window open
            WriteLine("Press any key to continue.");
            //closes window after key press
            ReadKey(true);
        }
    }
}