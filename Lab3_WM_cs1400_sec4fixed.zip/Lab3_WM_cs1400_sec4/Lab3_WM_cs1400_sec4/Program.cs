﻿// Author: Welsey Messer
// Assignment: Lab 3
// Instructor: InstructorName
// Class: CNS 1400 Section: 04 
// Date Written: 1/12/17 
// Description: a short program that asks for the users name, age, and money
// and then displays the users name their age plus 1, and the amount of money they have

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_WM_cs1400_sec4
{
    class Program
    {
        private static object console;

        static void Main(string[] args)
        {
            //variable declaration
            string name;
            int age = 0;
            double money =  0;

            
          

            //greets user and asks for their name
            Console.WriteLine("Hello my name is Hal.");
            Console.WriteLine("Please enter your name.");
            //gets users name
            name = (Console.ReadLine());
            //says users name and asks for thier age
            Console.WriteLine("Hello " {name} ",how old are you?");
            //gets users age
            age = int.Parse(Console.ReadLine());
            //adds one to age
            age = age + 1;        
            //asks user by name how much money they have
            Console.WriteLine("How much money do you have " {money} "?");
            //gets users money
            money = double.Parse(Console.ReadLine());
            //tells user how old they will be next year and how much money they have
            Console.WriteLine("Thank you " {name} "You are almost " { age} "years old and you have"{money} "");
        }
    }

}
