﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_6
{
    class Business_Logic
    {
        //Declaring Variables and constants
        double ShippingAmt;
        double NumOfBag = 0;
        int ShipType = 0;
        int ShipCatogory = 0;
        bool HiAlExtraShip = false;
        const double STANA = 3.00;
        const double STANB = 1.45;
        const double EXA = 4.00;
        const double EXB = 2.50;
        const double SAMEA = 5.50;
        const double SAMEB = 3.00;
        const double STANHIAL = 2.50;
        const double EXHIAL = 5.00;
        const double SAMEHIAL = 8.00;
        public Business_Logic()
        {
            ShippingAmt = 0.0;
            NumOfBag = 0;
            ShipType = 0;
            ShipCatogory = 0;
            HiAlExtraShip = false;
        }
        // The business_Logic method
        // Purpose: to calculate the shipping from user input and pass it to the calcbutton method
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: double
        public Business_Logic(double NumBag, int Shiptyp, int ShipCat, bool ExShip)
        {
            NumOfBag = NumBag;
            ShipType = Shiptyp;
            ShipCatogory = ShipCat;
            HiAlExtraShip = ExShip;
        }
        public double calculation()
        {
            //standard Shipping
            if (ShipType == 0)
            {
                //Catogory A
                if (ShipCatogory == 0)
                {
                    ShippingAmt = NumOfBag * STANA;
                    //shipping to Hawii or Alaska
               }
                //Catogory B
                else
                {
                    ShippingAmt = NumOfBag * STANB;

                }


                if (HiAlExtraShip == true)
                {
                    ShippingAmt = ShippingAmt + STANHIAL;
                }
                else
                {
                }
            }
            //Express Shipping
            else if (ShipType == 1)
            {
                //Catogory A
                if (ShipCatogory == 0)
                {
                    ShippingAmt = NumOfBag * EXA;
                    //shipping to Hawii or Alaska

                }
                //Catogory B
                else
                {
                    ShippingAmt = NumOfBag * EXB;

                }


                if (HiAlExtraShip == true)
                {
                    ShippingAmt = ShippingAmt + EXHIAL;
                }
                else
                {
                }
            }
            //Same Day Shipping
            else
            {
                ShippingAmt = NumOfBag * SAMEA;
                //Catogory A
                if (ShipCatogory == 0)
                {
                    //shipping to Hawii or Alaska
                    if (HiAlExtraShip == true)
                    {
                        ShippingAmt = ShippingAmt + SAMEHIAL;
                    }
                    //not shipping to Hawii or Alaska
                    else
                    {
                    }
                }
                //Catogory B
                else
                {
                    ShippingAmt = NumOfBag * SAMEB;
                    //shipping to Hawii or Alaska
                    if (HiAlExtraShip == true)
                    {
                        ShippingAmt = ShippingAmt + SAMEHIAL;
                    }
                    //not shipping to Hawii or Alaska
                    else
                    {
                    }                  
                }              
            }
            return ShippingAmt;
        }

    }
}
