﻿// Author: Welsey Messer    
// Assignment: Project 6
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004 
// Date Written: 3/10/2017 
// Description: a program to calculate shipping for a company with various parameters

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_6
{
    public partial class Form1 : Form
    {
        Business_Logic BL;
        public Form1()
        {
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // The abouttoolstripmenuitem method
        // Purpose: to tell info about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Wesley Messer\n Project #6\n Timothy D Stanley\n CS1400");
        }
        // The Calc button method
        // Purpose: to calculate the shipping cost from the buissness language class
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void CalcButton_Click(object sender, EventArgs e)
        {
            //gets info from user
            BL = new Business_Logic(double.Parse(BagNumBox.Text), ShippingBox.SelectedIndex, CatogoryBox.SelectedIndex, YesRadio.Checked);
            TotalCost.Text = $"{BL.calculation():C}";
        }
    }
}
