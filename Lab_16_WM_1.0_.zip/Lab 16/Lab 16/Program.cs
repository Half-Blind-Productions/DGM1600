﻿// File Prologue
// Name: wesley messer
// CS 1400
// instructor timothy D stanley
// Project: a program that tells you if you need to go to work or not and wear a 
// Date: 2/7/2017
// section 004

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.

using System;

class Program
{
    static void Main()
    {
        // declare some constants for saturday and sunday
        const string SAT = "Saturday";
        const string SUN = "Sunday";
        const int freezing = 32;

        // declare a variable to hold user's input
        string today;
        int temperature;

        // prompt the user to enter a day and get the input
        Console.Write("Please enter a day of the week, e.g. Tuesday: ");
        today = Console.ReadLine();

        // see if it is a work day
        if ((today != SUN && today != SAT)) //! ( A && B)
        {
            // prompt the user to enter a temperature and get the input
            Console.Write("Please enter a temperature in farenhight, e.g. 43\n");
            temperature = int.Parse(Console.ReadLine());
            // it is a workday, display the go to work message
            Console.Write("You have to go to work today...");
            //if the temperature is less then or eaqual to 32 Print Dress Warmly message with the go to work message
            if ((temperature <= freezing)) 
            {
                //prints "and dress wramly"
                Console.Write("and dress warmly");
            }
            //print empty string for good formatting
            Console.WriteLine("");
        }
        else
        {
            // its not a workday, display the weekend message
            Console.WriteLine("Ahh... the weekend. No work!");
        }

        
    }//End Main()
}//End class Program

//questions
//1.true
//2.true