﻿// File Prologue
// CS 1400-004
// Mary Coder
// Lab #8
// 2/7/2017
// instructor: Timothy D Stanley
// I did not copy any code except that provided by the instructor
//---------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare constants PI and NUMCIR(number of circles 4 in this case) 
            //declare variables radius, and SquArea, and CirArea and Result
            //get radius of circle from user
            // get area of square from user
            //take radius and multiply it by it’self (radius*radius) Then by constant PI
            //take result and set CirArea equal to it
            //subtract CirArea from SquArea set Result equal to This number
            //Trunkate Result down to two decimal places
            //parse result to string and display.
            ReadKey(true);
        }
    }
}
