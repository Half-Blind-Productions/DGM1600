﻿namespace Project_8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RollButton = new System.Windows.Forms.Button();
            this.DiceBoxOne = new System.Windows.Forms.PictureBox();
            this.DiceBoxTwo = new System.Windows.Forms.PictureBox();
            this.SnakeOrBoxCarLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiceBoxOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiceBoxTwo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // RollButton
            // 
            this.RollButton.Location = new System.Drawing.Point(72, 195);
            this.RollButton.Name = "RollButton";
            this.RollButton.Size = new System.Drawing.Size(131, 54);
            this.RollButton.TabIndex = 1;
            this.RollButton.Text = "Roll Out!";
            this.RollButton.UseVisualStyleBackColor = true;
            this.RollButton.Click += new System.EventHandler(this.RollButton_Click);
            // 
            // DiceBoxOne
            // 
            this.DiceBoxOne.Location = new System.Drawing.Point(26, 46);
            this.DiceBoxOne.Name = "DiceBoxOne";
            this.DiceBoxOne.Size = new System.Drawing.Size(100, 100);
            this.DiceBoxOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DiceBoxOne.TabIndex = 2;
            this.DiceBoxOne.TabStop = false;
            // 
            // DiceBoxTwo
            // 
            this.DiceBoxTwo.Location = new System.Drawing.Point(159, 46);
            this.DiceBoxTwo.Name = "DiceBoxTwo";
            this.DiceBoxTwo.Size = new System.Drawing.Size(100, 100);
            this.DiceBoxTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DiceBoxTwo.TabIndex = 3;
            this.DiceBoxTwo.TabStop = false;
            // 
            // SnakeOrBoxCarLabel
            // 
            this.SnakeOrBoxCarLabel.AutoSize = true;
            this.SnakeOrBoxCarLabel.Location = new System.Drawing.Point(119, 162);
            this.SnakeOrBoxCarLabel.Name = "SnakeOrBoxCarLabel";
            this.SnakeOrBoxCarLabel.Size = new System.Drawing.Size(0, 13);
            this.SnakeOrBoxCarLabel.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.SnakeOrBoxCarLabel);
            this.Controls.Add(this.DiceBoxTwo);
            this.Controls.Add(this.DiceBoxOne);
            this.Controls.Add(this.RollButton);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiceBoxOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DiceBoxTwo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button RollButton;
        private System.Windows.Forms.PictureBox DiceBoxOne;
        private System.Windows.Forms.PictureBox DiceBoxTwo;
        private System.Windows.Forms.Label SnakeOrBoxCarLabel;
    }
}

