﻿// Author: Welsey Messer
// Assignment:Project 8
// Instructor: Timothy D Stanley
// Class: CNS 1400 Section: 004 
// Date Written: 3/29/2017 
// Description:A graphical dice roller that displays the result of two dice rolled simultaniously

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Method Name:ExitToolStripMenuItem1 Method
        //Parameters:None
        //Returns:None
        //Purpose:to close the program when the exit button is cliked from the menu strip
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //Method Name:aboutToolStripMenuItem Method
        //Parameters:None
        //Returns:None
        //Purpose:To display info about the program
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name:Wesley Messer\nClass: CS 1400\nInstructor: Timothy D Stanley\nProject:8");
        }
        //Method Name:RollButton Method
        //Parameters:
        //Returns:
        //Purpose:generates two random values between 1-6 and displays the appropriate image representation of that dice face
        private void RollButton_Click(object sender, EventArgs e)
        {
            //declare variables and constants
            const int ONE = 1;
            const int TWO = 2;
            const int THREE = 3;
            const int FOUR = 4;
            const int FIVE = 5;
            const int SIX= 6;
            int DiceOne;
            int DiceTwo;
            int DicePicOne;
            int DicePicTwo;
            //generate two ramdom values between 1-6
            Random dice = new Random();
            DiceOne = dice.Next(1, 7);
            DiceTwo = dice.Next(1, 7);
            if (DiceOne == ONE)
            {
                DiceBoxOne.Image = Properties.Resources.dice1;
            }
            else if (DiceOne == TWO)
            {
                DiceBoxOne.Image = Properties.Resources.dice2;
            }
            else if (DiceOne == THREE)
            {
                DiceBoxOne.Image = Properties.Resources.dice3;
            }
            else if (DiceOne == THREE)
            {
                DiceBoxOne.Image = Properties.Resources.dice4;
            }
            else if (DiceOne == FOUR)
            {
                DiceBoxOne.Image = Properties.Resources.dice4;
            }
            else if (DiceOne == FIVE)
            {
                DiceBoxOne.Image = Properties.Resources.dice5;
            }
            else if (DiceOne == SIX)
            {
                DiceBoxOne.Image = Properties.Resources.dice6;
            }
            if (DiceTwo == ONE)
            {
                DiceBoxTwo.Image = Properties.Resources.dice1;
            }
            else if (DiceTwo == TWO)
            {
                DiceBoxTwo.Image = Properties.Resources.dice2;
            }
            else if (DiceTwo == THREE)
            {
                DiceBoxTwo.Image = Properties.Resources.dice3;
            }
            else if (DiceTwo == THREE)
            {
                DiceBoxTwo.Image = Properties.Resources.dice4;
            }
            else if (DiceTwo == FOUR)
            {
                DiceBoxTwo.Image = Properties.Resources.dice4;
            }
            else if (DiceTwo == FIVE)
            {
                DiceBoxTwo.Image = Properties.Resources.dice5;
            }
            else if (DiceTwo == SIX)
            {
                DiceBoxTwo.Image = Properties.Resources.dice6;
            }
            if (DiceOne == ONE && DiceTwo == ONE)
            {
                SnakeOrBoxCarLabel.Text = "SNAKE EYES!";
            }

            else if (DiceOne == SIX && DiceTwo == SIX)
            {
                SnakeOrBoxCarLabel.Text = "BOXCARS!";
            }
            else
            {
                SnakeOrBoxCarLabel.Text = "";
            }
        }
    }
}
