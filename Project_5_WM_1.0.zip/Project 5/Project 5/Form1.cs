﻿// Author: Wesley Messer
// Assignment: Project #5
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004 
// Date Written: 2/3/2017 
// Description: a program that takes a price and a unit amount and then calculates state tax local tax and the total

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_5
{
    public partial class Form1 : Form
    {
        //initializing the class
        SalesInvoice SI;
        public Form1()
        {
            //creates an object from the class
            SI = new SalesInvoice();
            InitializeComponent();
        }
        // The exitToolStripMenuItem1 method
        // Purpose: To close the window and terminate the application
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None       
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //closes the window
            this.Close();
        }
        // The AboutMenuItem1 method
        // Purpose: To dislplay information about the program
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name: Wesley Messer\n instructor: Timothy D Stanley\n Class: CS 1400\n Project 5");
        }
        // The BuyButton method
        // Purpose: to take the information given by the user and calculate the total price, sales tax, local tax, etc
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void BuyButton_Click(object sender, EventArgs e)
        {
            // gets info for price and unit number from user
            string quanity = ItemBox.Text;
            double numUnits = double.Parse(UnitBox.Text);
            //formats price for value
            string unit = $"{numUnits:c}";
            //converts info for price and unit number from string to int
            SI.setitem(int.Parse(ItemBox.Text));
            SI.setPrice(double.Parse(UnitBox.Text));
            //calls methods from Sales invoice class and stores the value returned into a string
            string net = $"{SI.CalcNetSales():c}";
            string State = $"{SI.CalcStateTax():c}";
            string Local = $"{SI.CalcLocalTax():c}";
            string gross = $"{SI.CalcGrossSales():c}";
            //shows the info obtained from the method calculations that have been called and the values returned
            MessageBox.Show("Sales Ticket...\n"+"Quantity:" + quanity + " units\n" + "----------------------------------\n" + "unit Price:" + unit + " each\n" + "Net Price" + net + "\n" + "State Sales Tax:" + State + "\n" + "Local Sales Tax" + Local + "\n" + "Please pay:" + gross);
        }
        // The ClearButton method
        // Purpose: to clear all text fields
        // Parameters: The object generating the event 
        // and the event arguments
        // Returns: None
        private void ClearButton_Click(object sender, EventArgs e)
        {
           ItemBox.Clear();
            UnitBox.Clear();
        }
    }
}
