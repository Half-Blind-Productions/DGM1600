﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_5
{
    class SalesInvoice
    {
        //declaring variables and constants
        private int Itemssold ;
        private double ItemPrice;
        private const double STATETAX = .00745;
        private const double LOCALTAX = .0025;
        // The setitem method
        // Purpose: to set the value of itemssold 
        // Parameters: int item
        // Returns: None
        public void setitem(int item)
        {
            Itemssold = item;
        }
        // The setPrice method
        // Purpose: to set the value of ItemPrice 
        // Parameters: double price
        // Returns: None
        public void setPrice (double Price)
        {
            ItemPrice = Price;
        }
        // The CalcNetSales method
        // Purpose: to calculate the net cost 
        // Parameters: none
        // Returns: double
        public double CalcNetSales()
        {
            return Itemssold * ItemPrice;
        }
        // The CalcNetStateTax method
        // Purpose: to calculate the state tax from the net cost 
        // Parameters: none
        // Returns: double
        public double CalcStateTax()
        {
            //calculates state tax
            double netSale = CalcNetSales();
            double statetax = netSale * STATETAX;
            return statetax;
        }
        // The CalcLocalTax method
        // Purpose: to calculate Local Tax from the net cost 
        // Parameters: none
        // Returns: double
        public double CalcLocalTax()
        {
            //calculates Local tax
            double netSale = CalcNetSales();
            double LocalTax = netSale * LOCALTAX;
            return LocalTax;
        }
        // The CalcGrossSales method
        // Purpose: to calculate the gross cost by adding the local tax, state tax, and net price  
        // Parameters: none
        // Returns: double
        public double CalcGrossSales()
        {
            //calculates gross sale total
            return CalcNetSales() + CalcStateTax() + CalcLocalTax();
        }
    }
}
