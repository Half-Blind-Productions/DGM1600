﻿// Author: Wesley Messer    
// Assignment: Lab 26
// Instructor: Timothy D stanley
// Class: CNS 1400 Section: 004
// Date Written: 4/19/2017
// Description: to open and display the first line from a text file

//I declare that the following source code was written solely by me.
//I understand that copying any source code, in whole or in part, 
// constitutes cheating, and that I will receive a zero on this project
// if I am found in violation of this policy.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab_26
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// Name: PpenToolStripMenuItem
        /// Parameters:none
        /// Returns: none
        /// Purpose: to open a file and display it's first line in a text box
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "text files (*.txt)|*txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = openFileDialog1.OpenFile()) != null)
                {
                    StreamReader data = new StreamReader(myStream);
                    textBox.Text = data.ReadLine();
                }
            }
        }

/// Name: ExitToolStripMenuItem1
/// Parameters:none
/// Returns: none
/// Purpose: to close the program
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// Name: AboutToolStripMenuItem
        /// Parameters:none
        /// Returns: none
        /// Purpose: to show information about the program
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name: WesleyMesser\nClass: cs 1400\nSection: 004\nInstructor: Timothy D Stanley\nAssignment: Lab 26");
        }
    }
}