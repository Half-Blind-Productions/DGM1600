﻿namespace Lab4_wm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DiamLabel = new System.Windows.Forms.Label();
            this.RPMiLabel = new System.Windows.Forms.Label();
            this.DiamBox = new System.Windows.Forms.TextBox();
            this.RPMiBox = new System.Windows.Forms.TextBox();
            this.ClearButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(212, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // DiamLabel
            // 
            this.DiamLabel.AutoSize = true;
            this.DiamLabel.Location = new System.Drawing.Point(53, 36);
            this.DiamLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DiamLabel.Name = "DiamLabel";
            this.DiamLabel.Size = new System.Drawing.Size(92, 13);
            this.DiamLabel.TabIndex = 1;
            this.DiamLabel.Text = "Diameter of wheel";
            // 
            // RPMiLabel
            // 
            this.RPMiLabel.AutoSize = true;
            this.RPMiLabel.Location = new System.Drawing.Point(59, 98);
            this.RPMiLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.RPMiLabel.Name = "RPMiLabel";
            this.RPMiLabel.Size = new System.Drawing.Size(91, 13);
            this.RPMiLabel.TabIndex = 2;
            this.RPMiLabel.Text = "Rotations per mile";
            // 
            // DiamBox
            // 
            this.DiamBox.Location = new System.Drawing.Point(65, 65);
            this.DiamBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DiamBox.Name = "DiamBox";
            this.DiamBox.Size = new System.Drawing.Size(76, 20);
            this.DiamBox.TabIndex = 0;
            this.DiamBox.Leave += new System.EventHandler(this.DiamBox_Leave);
            // 
            // RPMiBox
            // 
            this.RPMiBox.Location = new System.Drawing.Point(65, 128);
            this.RPMiBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RPMiBox.Name = "RPMiBox";
            this.RPMiBox.Size = new System.Drawing.Size(76, 20);
            this.RPMiBox.TabIndex = 1;
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(76, 167);
            this.ClearButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(56, 19);
            this.ClearButton.TabIndex = 2;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            this.ClearButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ClearButton_MouseDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 206);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.RPMiBox);
            this.Controls.Add(this.DiamBox);
            this.Controls.Add(this.RPMiLabel);
            this.Controls.Add(this.DiamLabel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "CS 1400 Lab#7";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label DiamLabel;
        private System.Windows.Forms.Label RPMiLabel;
        private System.Windows.Forms.TextBox DiamBox;
        private System.Windows.Forms.TextBox RPMiBox;
        private System.Windows.Forms.Button ClearButton;
    }
}

